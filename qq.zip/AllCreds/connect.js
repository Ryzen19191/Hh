const {
  'default': makeWASocket,
  useMultiFileAuthState,
  makeInMemoryStore,
  DisconnectReason,
  WAGroupMetadata,
  relayWAMessage,
  MediaPathMap,
  mentionedJid,
  processTime,
  MediaType,
  Browser,
  MessageType,
  Presence,
  Mimetype,
  Browsers,
  delay,
  fetchLatestBaileysVersion,
  MessageRetryMap,
  extractGroupMetadata,
  generateWAMessageFromContent,
  proto,
  otherOpts,
  makeCacheableSignalKeyStore
} = require('@whiskeysockets/baileys');
const {
  fs,
  Boom,
  axios,
  crypto,
  util,
  P,
  linkfy,
  request,
  cheerio,
  ms,
  exec,
  moment,
  time,
  hora,
  date,
  getBuffer,
  fetchJson,
  getBase64,
  upload,
  banner2,
  banner3,
  colors,
  getGroupAdmins
} = require('./exports.js');
const {
  menu,
  anotacao,
  menudono,
  adms,
  menulogos,
  efeitos,
  menuprem,
  brincadeiras,
  infodono,
  alteradores,
  destrava,
  destrava2,
  tabela,
  conselhob,
  palavrasc,
  ban,
  joguinhodavelhajs,
  joguinhodavelhajs2,
  nescessario,
  setting,
  logoslink,
  premium,
  countMessage,
  sendVideoAsSticker,
  sendImageAsSticker,
  sendVideoAsSticker2,
  sendImageAsSticker2,
  sotoy,
  daily,
  comandos,
  limitefll,
  antispam,
  anotar,
  getRandom,
  NodeCache,
  insert,
  response
} = require("./exports.js");
const {
  NomeDoBot,
  NickDono,
  prefix
} = require("./settings/settings.json");
var {
  fundo1,
  fundo2
} = require("./settings/links_img.json");
function DLT_FL(_0x3113e0) {
  try {
    fs.unlinkSync(_0x3113e0);
  } catch (_0x14a4cc) {}
}
const kontol_info2 = console.info;
console.info = function () {
  if (!util.format(...arguments).includes("Closing session: SessionEntry")) {
    return kontol_info2(...arguments);
  }
};
const kontol_info1 = console.info;
console.info = function () {
  if (!util.format(...arguments).includes("Removing old closed session: SessionEntry {}")) {
    return kontol_info1(...arguments);
  }
};
const msgRetryCounterCache = new NodeCache();
const readline = require("readline");
const pairingCode = process.argv.includes("sim");
const rl = readline.createInterface({
  'input': process.stdin,
  'output': process.stdout
});
const question = _0x30aa42 => new Promise(_0x2469a2 => rl.question(_0x30aa42, _0x2469a2));
async function iniciartednexmart() {
  const {
    state: _0x5dc862,
    saveCreds: _0x3079aa
  } = await useMultiFileAuthState("./database/tednexMart-qr");
  const {
    version: _0x211649,
    isLatest: _0x1189c9
  } = await fetchLatestBaileysVersion();
  const _0x56ea70 = makeWASocket({
    'version': _0x211649,
    'auth': _0x5dc862,
    'syncFullHistory': true,
    'printQRInTerminal': !pairingCode,
    'qrTimeout': 0x2bf20,
    'logger': P({
      'level': "silent"
    }),
    'browser': ["Ubuntu", "Chrome", "20.0.04"],
    'msgRetryCounterCache': msgRetryCounterCache,
    'connectTimeoutMs': 0xea60,
    'defaultQueryTimeoutMs': 0x0,
    'keepAliveIntervalMs': 0x2710,
    'emitOwnEvents': true,
    'fireInitQueries': true,
    'generateHighQualityLinkPreview': true,
    'syncFullHistory': true,
    'markOnlineOnConnect': true,
    'patchMessageBeforeSending': _0x231856 => {
      const _0x4b6636 = !!(_0x231856.buttonsMessage || _0x231856.listMessage);
      if (_0x4b6636) {
        _0x231856 = {
          'viewOnceMessage': {
            'message': {
              'messageContextInfo': {
                'deviceListMetadataVersion': 0x2,
                'deviceListMetadata': {}
              },
              ..._0x231856
            }
          }
        };
      }
      return _0x231856;
    }
  });
  if (pairingCode && !_0x56ea70.authState.creds.registered) {
    try {
      let _0x126ea2 = await question('' + colors.gray("Exemplo do número para realizar a conexão do bot: +55 82 9999-9999. (Coloque do jeito que está no WhatsApp)") + colors.cyan("\n• Insira no parâmetro o número de telefone que você deseja conectar o bot: "));
      _0x126ea2 = _0x126ea2.replace(/[^0-9]/g, '');
      let _0x50343d = await _0x56ea70.requestPairingCode(_0x126ea2);
      _0x50343d = _0x50343d?.["match"](/.{1,4}/g)?.["join"]('-') || _0x50343d;
      console.log('' + colors.cyan("• Código para conectar o bot e desfrutar de suas imensas funcionalidades: ") + colors.white(_0x50343d));
      rl.close();
    } catch (_0x269b26) {
      console.error("Falha ao solicitar o código de registro. Por favor, tente novamente.\n", _0x269b26);
    }
  }
  _0x56ea70.ev.process(async _0x2506bd => {
    if (_0x2506bd['group-participants.update']) {
      try {
        var _0x4a3d8c = _0x2506bd["group-participants.update"];
        if (!fs.existsSync("./database/grupos/activation_gp/" + _0x4a3d8c.id + '.json')) {
          return;
        }
        var _0x55ca29 = JSON.parse(fs.readFileSync("./database/grupos/activation_gp/" + _0x4a3d8c.id + ".json"));
        if (_0x4a3d8c.participants[0x0].startsWith(_0x56ea70.user.id.split(':')[0x0])) {
          return;
        }
        try {
          var _0x418925 = await _0x56ea70.groupMetadata(_0x4a3d8c.id);
        } catch (_0x46547b) {
          return;
        }
        const _0x5c6264 = _0x418925.id.endsWith('@g.us');
        try {
          var _0x4d168a = _0x5c6264 ? await _0x56ea70.groupMetadata(_0x4a3d8c.id) : '';
        } catch (_0x24cdf2) {
          return;
        }
        if (_0x4a3d8c.action == "add") {
          num = _0x4a3d8c.participants[0x0];
          if (nescessario.listanegraG.includes(num)) {
            await _0x56ea70.sendMessage(_0x4d168a.id, {
              'text': "Olha quem deu as cara por aqui, sente o poder do ban..."
            });
            _0x56ea70.groupParticipantsUpdate(_0x4d168a.id, [_0x4a3d8c.participants[0x0]], 'remove');
            return;
          }
        }
        if (_0x4a3d8c.action == 'remove') {
          num = _0x4a3d8c.participants[0x0];
        }
        if (_0x4a3d8c.action == "add" && _0x55ca29[0x0].listanegra.includes(_0x4a3d8c.participants[0x0])) {
          await _0x56ea70.sendMessage(_0x4d168a.id, {
            'text': "Olha quem deu as cara por aqui, sente o poder do ban cabaço..."
          });
          _0x56ea70.groupParticipantsUpdate(_0x4d168a.id, [_0x4a3d8c.participants[0x0]], "remove");
        }
        if (_0x55ca29[0x0].antifake && _0x4a3d8c.action === "add" && !_0x4a3d8c.participants[0x0].startsWith(0x37)) {
          if (_0x55ca29[0x0].legenda_estrangeiro != '0') {
            await _0x56ea70.sendMessage(_0x4d168a.id, {
              'text': _0x55ca29[0x0].legenda_estrangeiro
            });
          }
          setTimeout(async () => {
            _0x56ea70.groupParticipantsUpdate(_0x4d168a.id, [_0x4a3d8c.participants[0x0]], "remove");
          }, 0x3e8);
        }
        if (!_0x55ca29[0x0].wellcome[0x1].bemvindo2 && !_0x55ca29[0x0].wellcome[0x0].bemvindo1) {
          return;
        }
        try {
          var _0x50f74c = _0x5c6264 ? await _0x56ea70.groupMetadata(_0x4a3d8c.id) : '';
        } catch (_0x383f79) {
          return;
        }
        const _0xb88040 = !!(_0x55ca29[0x0].wellcome[0x0].legendabv != null);
        const _0x1fa7db = !!(_0x55ca29[0x0].wellcome[0x0].legendasaiu != 0x0);
        const _0x2f9b0d = !!(_0x55ca29[0x0].wellcome[0x1].legendabv != null);
        const _0x334884 = !!(_0x55ca29[0x0].wellcome[0x1].legendasaiu != 0x0);
        const _0x93323a = await _0x50f74c.desc;
        if (_0x55ca29[0x0].antifake == true && !_0x4a3d8c.participants[0x0].startsWith(0x37)) {
          return;
        }
        if (_0x55ca29[0x0].wellcome[0x0].bemvindo1 == true) {
          try {
            ppimg = await _0x56ea70.profilePictureUrl(_0x4a3d8c.participants[0x0]);
          } catch (_0x52f734) {
            ppimg = "https://telegra.ph/file/24fa902ead26340f3df2c.png";
          }
          try {
            ppgp = await _0x56ea70.profilePictureUrl(_0x50f74c.id);
          } catch (_0xa9eb90) {
            ppgp = 'https://telegra.ph/file/24fa902ead26340f3df2c.png';
          }
          shortpc = await axios.get('https://tinyurl.com/api-create.php?url=' + ppimg);
          if (_0x4a3d8c.action === "add") {
            if (_0xb88040) {
              teks = _0x55ca29[0x0].wellcome[0x0].legendabv.replace("#hora#", time).replace("#nomedogp#", _0x50f74c.subject).replace('#numerodele#', '@' + _0x4a3d8c.participants[0x0].split('@')[0x0]).replace("#numerobot#", _0x56ea70.user.id).replace("#prefixo#", _0x55ca29[0x0].multiprefix == true ? _0x55ca29[0x0].prefixos[0x0] : setting.prefix).replace("#descrição#", _0x93323a);
            } else {
              teks = welcome(_0x4a3d8c.participants[0x0].split('@')[0x0], _0x50f74c.subject);
            }
            let _0x2b585c = await getBuffer(ppimg);
            ran = getRandom(".jpg");
            await fs.writeFileSync(ran, _0x2b585c);
            ranBV = ["ao grupo " + encodeURI(_0x50f74c.subject), "O membro " + _0x4a3d8c.participants[0x0].split('@')[0x0] + " acaba de cair de paraquedas aqui no grupo...", "Leia a descrição do grupo para passar um tempo aqui...", "Minhas saudações a você, novo membro desconhecido.", "Ih você é o novo membro? Te desejo boas vindas ao Hospício kkk!", "Acaba de chegar + um de paraquedas aqui no grupo!"];
            _0x56ea70.sendMessage(_0x50f74c.id, {
              'image': {
                'url': "https://tedzinho.online/api/canvas/welcome?titulo=Bem-vindo(a)!&perfil=" + shortpc.data + '&fundo=' + fundo1 + "&desc=" + ranBV[Math.floor(Math.random() * ranBV.length)]
              },
              'mentions': _0x4a3d8c.participants,
              'caption': teks
            });
            DLT_FL(ran);
          } else {
            if (_0x4a3d8c.action === 'remove') {
              _0x364fd9 = _0x4a3d8c.participants[0x0];
              try {
                ppimg = await _0x56ea70.profilePictureUrl(_0x364fd9.split('@')[0x0] + "@c.us");
              } catch (_0x805902) {
                ppimg = 'https://telegra.ph/file/24fa902ead26340f3df2c.png';
              }
              if (_0x1fa7db) {
                teks = _0x55ca29[0x0].wellcome[0x0].legendasaiu.replace("#hora#", time).replace("#nomedogp#", _0x50f74c.subject).replace("#numerodele#", _0x4a3d8c.participants[0x0].split('@')[0x0]).replace("#numerobot#", _0x56ea70.user.id).replace('#prefixo#', _0x55ca29[0x0].multiprefix == true ? _0x55ca29[0x0].prefixos[0x0] : setting.prefix).replace("#descrição#", _0x93323a);
              } else {
                teks = bye(_0x4a3d8c.participants[0x0].split('@')[0x0]);
              }
              let _0x345aea = await getBuffer(ppimg);
              ran = getRandom(".jpg");
              fs.writeFileSync(ran, _0x345aea);
              ranSI = ['' + _0x4a3d8c.participants[0x0].split('@')[0x0], "Nem gostava de você, eu só digo aleluia por tu ter saído :)", "Nunca fui com a tua cara, digo glória por tu ter saído!", "Eu te amo demais, volta pra cá. Aqui é teu lar!", "Nada pra ver aqui, ele(a) saiu por um 'acidente'..."];
              _0x56ea70.sendMessage(_0x50f74c.id, {
                'image': {
                  'url': "https://tedzinho.online/api/canvas/welcome?titulo=Adeus!&perfil=" + shortpc.data + "&fundo=" + fundo2 + '&desc=' + ranSI[Math.floor(Math.random() * ranSI.length)]
                },
                'caption': teks,
                'mentions': _0x4a3d8c.participants
              });
              DLT_FL(ran);
            }
          }
        }
        if (_0x55ca29[0x0].wellcome[0x1].bemvindo2 == true) {
          if (_0x4a3d8c.action === "add") {
            if (_0x2f9b0d) {
              teks = _0x55ca29[0x0].wellcome[0x1].legendabv.replace("#hora#", time).replace("#nomedogp#", _0x50f74c.subject).replace("#numerodele#", _0x4a3d8c.participants[0x0].split('@')[0x0]).replace("#numerobot#", _0x56ea70.user.id).replace("#prefixo#", _0x55ca29[0x0].multiprefix == true ? _0x55ca29[0x0].prefixos[0x0] : setting.prefix).replace("#descrição#", _0x93323a);
            } else {
              teks = welcome2(_0x4a3d8c.participants[0x0].split('@')[0x0], _0x50f74c.subject);
            }
            _0x56ea70.sendMessage(_0x50f74c.id, {
              'text': teks,
              'mentions': _0x4a3d8c.participants
            });
          } else {
            if (_0x4a3d8c.action === "remove") {
              var _0x364fd9 = _0x4a3d8c.participants[0x0];
              if (_0x334884) {
                teks = _0x55ca29[0x0].wellcome[0x1].legendasaiu.replace("#hora#", time).replace("#nomedogp#", _0x50f74c.subject).replace("#numerodele#", _0x364fd9.split('@')[0x0]).replace("#numerobot#", _0x56ea70.user.id).replace("#prefixo#", _0x55ca29[0x0].multiprefix == true ? _0x55ca29[0x0].prefixos[0x0] : setting.prefix).replace('#descrição#', _0x93323a);
              } else {
                teks = bye2(_0x364fd9.split('@')[0x0]);
              }
              _0x56ea70.sendMessage(_0x50f74c.id, {
                'text': teks,
                'mentions': _0x4a3d8c.participants
              });
            }
          }
        }
      } catch (_0x452ab5) {
        console.log(_0x452ab5);
      }
    }
    if (_0x2506bd["messages.upsert"]) {
      var _0x50b945 = _0x2506bd["messages.upsert"];
      require("./index.js")(_0x50b945, _0x56ea70);
    }
    if (_0x2506bd['connection.update']) {
      const _0xfcb61f = _0x2506bd["connection.update"];
      var {
        connection: _0x1a0609,
        lastDisconnect: _0x1d8dc3,
        qr: _0x22ba4e,
        isNewLogin: _0x22ba64,
        receivedPendingNotifications: _0x2ce4d2
      } = _0xfcb61f;
      if (_0x22ba4e) {
        console.log(colors.green("Você precisará de um 2° celular, para tirar foto do tednexMart-qr, para depois escanear a foto que tirou.."));
      }
      const _0x81852c = new Boom(_0x1d8dc3?.["error"])?.["output"]["statusCode"];
      switch (_0x1a0609) {
        case "close":
          if (_0x81852c) {
            if (_0x81852c == 0x1ac) {
              console.log(colors.yellow("[Error: 428] - Conexão caiu, irei ligar novamente, se continuar com este erro, provavelmente sua internet está caindo constantemente..."));
            } else {
              if (_0x81852c == 0x191) {
                exec("cd database && rm -rf tednexMart-qr");
                console.log(colors.red("A autenticação com WhatsApp Web falhou! Por favor, reinicie e realize a autenticação novamente."));
              } else {
                if (_0x81852c == 0x203) {
                  console.log(colors.gray("\nA autenticação foi bem sucedida! Restart necessário para estabilizar a conexão."));
                } else {
                  if (_0x81852c == 0x1b8) {
                    console.log(colors.gray("Está tendo um pequeno conflito, se isso aparecer mais de 4 vez, creio que há uma outra sessão aberta, ou o bot ligado em outro lugar, caso contrário ignore..."));
                  } else {
                    if (_0x81852c == 0x1f7) {
                      console.log(colors.grey("[Error: 503] - Ocorreu um erro desconhecido ao executar o bot novamente ou sua primeira inicialização."));
                    } else {
                      if (_0x81852c == 0x1f6) {
                        console.log(colors.grey("[Error: 502] - A conexão com a internet, está querendo cair..."));
                      } else if (_0x81852c == 0x198) {
                        console.log(colors.gray("[Error: 408] - A conexão com a Internet atualmente está fraca..."));
                      } else {
                        console.log(colors.yellow("[CONEXÃO CLOSED] - A conexão entre o WhatsApp foi fechada, por motivos de: " + _0x1d8dc3?.["error"]));
                      }
                    }
                  }
                }
              }
            }
            ;
            iniciartednexmart();
          }
          break;
        case "connecting":
          console.log(colors.yellow("[BOT] Reconectando / Iniciando - " + date + " " + time));
          break;
        case "open":
          console.log(banner3.string);
          console.log(banner2.string);
          console.log(colors.green("〔 - _ TED-BOT 𝐕𝟑.9 _ - CONECTADA COM SUCESSO... 〕"));
          await _0x56ea70.sendPresenceUpdate("available");
          await _0x56ea70.updateProfileStatus("Olá meu nome é " + NomeDoBot + "  Esse é meu prefix(" + prefix + ')');
          break;
        default:
          break;
      }
    }
    if (_0x2506bd["creds.update"]) {
      await _0x3079aa();
    }
    ;
    require("./index.js")(_0x56ea70, "./database/tednexMart-qr");
  });
}
iniciartednexmart()['catch'](async _0x2ad3dc => {
  console.log(colors.red("• ERROR: " + _0x2ad3dc));
});