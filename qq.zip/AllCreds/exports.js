const {
  'default': makeWASocket,
  downloadContentFromMessage,
  fetchLatestBaileysVersion,
  useMultiFileAuthState,
  makeInMemoryStore,
  DisconnectReason,
  WAGroupMetadata,
  relayWAMessage,
  MediaPathMap,
  mentionedJid,
  processTime,
  MediaType,
  Browser,
  MessageType,
  Presence,
  Mimetype,
  Browsers,
  delay,
  MessageRetryMap
} = require("@whiskeysockets/baileys");
const {
  Boom
} = require("@hapi/boom");
const AssemblyAI = require("assemblyai");
const axios = require("axios");
const fs = require("fs-extra");
const cheerio = require("cheerio");
const util = require("util");
const PhoneNumber = require('awesome-phonenumber');
const {
  randomBytes
} = require("crypto");
const P = require('pino');
const NodeCache = require("node-cache");
const linkfy = require("linkifyjs");
const request = require("request");
const ms = require('ms');
const os = require('os');
const ffmpeg = require("fluent-ffmpeg");
const fetch = require('node-fetch');
const qrterminal = require("qrcode-terminal");
const {
  exec,
  spawn,
  execSync
} = require("child_process");
const moment = require("moment-timezone");
const colors = require('colors');
const yts = require('yt-search');
const infoSystem = require('os');
const {
  Emoji
} = require("emoji-api");
const emoji = new Emoji({});
const time = moment.tz("America/Sao_Paulo").format("HH:mm:ss");
const hora = moment.tz("America/Sao_Paulo").format("HH:mm:ss");
const date = moment.tz("America/Sao_Paulo").format("DD/MM/YYYY");
const webp_mp4 = require("./arquivos/js/webp_mp4.js");
const {
  sendVideoAsSticker,
  sendImageAsSticker
} = require("./arquivos/sticker/rename.js");
const {
  sendVideoAsSticker2,
  sendImageAsSticker2
} = require("./arquivos/sticker/rename2.js");
const {
  arcloud
} = require("./arquivos/js/arcc.js");
const {
  addLimit,
  getLimit
} = require('./arquivos/js/limit.js');
const {
  addBanned,
  unBanned,
  BannedExpired,
  cekBannedUser
} = require("./arquivos/js/banned.js");
const {
  validmove,
  setGame
} = require("./arquivos/tictactoe");
const {
  addComandosId,
  deleteComandos,
  getComandoBlock,
  getComandos,
  addComandos
} = require("./arquivos/js/addcmd.js");
const {
  palavrasANA,
  quizanimais,
  enigmaArchive,
  garticArchives,
  whatMusicAr
} = require('./arquivos/js/jogos.js');
const {
  wait,
  getExtension,
  generateMessageID,
  getMembros,
  getGroupAdmins,
  getRandom,
  banner,
  banner2,
  banner3,
  temporizador,
  chyt,
  getBuffer,
  fetchJson,
  fetchText,
  createExif,
  getBase64,
  convertSticker,
  upload,
  nit,
  getpc,
  supre,
  recognize
} = require("./arquivos/funcoes/functions.js");
const {
  writeExifImg
} = require("./arquivos/sticker/exif.js");
const {
  writeExif2
} = require("./arquivos/sticker/exif2.js");
const {
  infoClima
} = require('./arquivos/funcoes/infoclima.js');
const {
  isFiltered,
  addFilter
} = require("./arquivos/funcoes/functions.js");
const {
  MultiDownload
} = require("./arquivos/funcoes/multidl.js");
const rgtake = JSON.parse(fs.readFileSync("./database/usuarios/take.json"));
const sotoy = JSON.parse(fs.readFileSync("./arquivos/json/sotoy.json"));
const piadas = JSON.parse(fs.readFileSync('./arquivos/json/piadas.json'));
const countMessage = JSON.parse(fs.readFileSync('./settings/media/countmsg.json'));
const comandos = JSON.parse(fs.readFileSync("./settings/media/comandos.json"));
const daily = JSON.parse(fs.readFileSync('./database/usuarios/diario.json'));
const nescessario = JSON.parse(fs.readFileSync("./settings/nescessario.json"));
const premium = JSON.parse(fs.readFileSync("./database/usuarios/premium.json"));
const ban = JSON.parse(fs.readFileSync('./database/usuarios/banned.json'));
const muted = JSON.parse(fs.readFileSync("./database/usuarios/muted.json"));
const limitefll = JSON.parse(fs.readFileSync("./database/usuarios/flood.json"));
const joguinhodavelhajs = JSON.parse(fs.readFileSync("./database/usuarios/joguinhodavelha.json"));
const {
  insert,
  response
} = require("./arquivos/funcoes/simi.js");
const {
  randomCantadas
} = require('./arquivos/js/cantadas.js');
const joguinhodavelhajs2 = JSON.parse(fs.readFileSync("./database/usuarios/joguinhodavelha2.json"));
const autorpg = JSON.parse(fs.readFileSync('./database/usuarios/SystemRPG/autorpg.json'));
const sabrpg = JSON.parse(fs.readFileSync("./database/usuarios/SystemRPG/sabrpg.json"));
const bcbet = JSON.parse(fs.readFileSync('./database/usuarios/SystemRPG/1xbcbet.json'));
const minerar = JSON.parse(fs.readFileSync('./database/usuarios/SystemRPG/minerar.json'));
const coderpg = JSON.parse(fs.readFileSync("./database/usuarios/SystemRPG/coderpg.json"));
const elitepasse = JSON.parse(fs.readFileSync("./database/usuarios/SystemRPG/passerpg.json"));
const cavalosrpg = JSON.parse(fs.readFileSync("./database/usuarios/SystemRPG/cavalosrpg.json"));
const galosrpg = JSON.parse(fs.readFileSync("./database/usuarios/SystemRPG/galosrpg.json"));
const roubosrpg = JSON.parse(fs.readFileSync("./database/usuarios/SystemRPG/roubosrpg.json"));
const antispam = JSON.parse(fs.readFileSync("./settings/media/antispam.json"));
const anotar = JSON.parse(fs.readFileSync('./database/func/anotar.json'));
const setting = JSON.parse(fs.readFileSync('./settings/settings.json'));
const logoslink = JSON.parse(fs.readFileSync("./settings/links_img.json"));
const Limit_CMD = JSON.parse(fs.readFileSync("./database/func/limitarcmd.json"));
const ftmenu = JSON.parse(fs.readFileSync('./settings/logos.json'));
const black_ = JSON.parse(fs.readFileSync("./database/grupos/avisos.json"));
const level2 = JSON.parse(fs.readFileSync("./database/usuarios/leveling.json"));
const votacao = JSON.parse(fs.readFileSync("./database/func/votacao/voting.json"));
const {
  linguagem,
  mess,
  getInfo
} = require("./settings/lib");
const {
  psycatgames
} = require('./arquivos/funcoes/psycatgames.js');
const {
  destrava,
  destrava2
} = require("./arquivos/funcoes/destrava.js");
const {
  tabela
} = require("./arquivos/js/tabela.js");
const {
  conselhob
} = require('./arquivos/js/conselhob.js');
const {
  fatos
} = require("./arquivos/js/fatos.js");
const {
  palavrasc
} = require("./arquivos/js/conselhos.js");
const {
  getMinesPositions,
  MinesHelp
} = require("./arquivos/js/mines.js");
const mines = JSON.parse(fs.readFileSync("./database/grupos/games/mines.json"));
function DLT_FL(_0x1077f2) {
  try {
    fs.unlinkSync(_0x1077f2);
  } catch (_0x1ccfe1) {}
}
if (!nescessario.botoes_) {
  var EnvBotao = async (_0x170e05, _0x15b95f, _0x408bc2, _0x462b2c, _0x5bfb5e, _0x186f44) => {
    if (_0x186f44.split('|')[0x1] != '0') {
      _0x408bc2.sendMessage(_0x170e05, {
        'image': {
          'url': _0x186f44.split('|')[0x1]
        },
        'caption': _0x462b2c,
        'mentions': [_0x15b95f]
      });
    } else {
      _0x408bc2.sendMessage(_0x170e05, {
        'text': _0x462b2c,
        'mentions': [_0x15b95f]
      });
    }
  };
} else {
  var EnvBotao = async (_0x59377b, _0x4cb335, _0x255b00, _0x4be2f3, _0x4c1cd9, _0x57bcaf, _0x2029ac = [], _0x8717e5) => {
    var _0x2237db = _0x57bcaf.split('|')[0x0].charAt(0x0);
    var _0x5bde17 = _0x2237db == '1' ? [{
      'buttonId': _0x2029ac[0x0],
      'buttonText': {
        'displayText': _0x2029ac[0x1]
      },
      'type': 0x1
    }] : _0x2237db == '2' ? [{
      'buttonId': _0x2029ac[0x0],
      'buttonText': {
        'displayText': _0x2029ac[0x1]
      },
      'type': 0x1
    }, {
      'buttonId': _0x2029ac[0x2],
      'buttonText': {
        'displayText': _0x2029ac[0x3]
      },
      'type': 0x1
    }] : _0x2237db == '3' ? [{
      'buttonId': _0x2029ac[0x0],
      'buttonText': {
        'displayText': _0x2029ac[0x1]
      },
      'type': 0x1
    }, {
      'buttonId': _0x2029ac[0x2],
      'buttonText': {
        'displayText': _0x2029ac[0x3]
      },
      'type': 0x1
    }, {
      'buttonId': _0x2029ac[0x4],
      'buttonText': {
        'displayText': _0x2029ac[0x5]
      },
      'type': 0x1
    }] : '';
    if (_0x57bcaf.split('|')[0x1] == '0' && !_0x57bcaf.split('|')[0x0].includes('v')) {
      var _0x30289b = {
        'text': _0x4be2f3,
        'footer': _0x4c1cd9,
        'buttons': _0x5bde17,
        'headerType': 0x1,
        'mentions': [_0x4cb335]
      };
    } else {
      if (_0x57bcaf.split('|')[0x1] != '0' && !_0x57bcaf.split('|')[0x0].includes('v')) {
        var _0x30289b = {
          'image': {
            'url': _0x57bcaf.split('|')[0x1]
          },
          'caption': _0x4be2f3,
          'footer': _0x4c1cd9,
          'buttons': _0x5bde17,
          'headerType': 0x1,
          'mentions': [_0x4cb335]
        };
      } else {
        if (_0x57bcaf.split('|')[0x1] != '0' && _0x57bcaf.split('|')[0x0].includes('v')) {
          var _0x30289b = {
            'video': {
              'url': _0x57bcaf.split('|')[0x1]
            },
            'caption': _0x4be2f3,
            'footer': _0x4c1cd9,
            'buttons': _0x5bde17,
            'headerType': 0x1,
            'mentions': [ME]
          };
        }
      }
    }
    _0x255b00.sendMessage(_0x59377b, _0x30289b, {
      'quoted': _0x8717e5
    })["catch"](_0x54e5a1 => {
      return console.log("Erro no botão, Tente novamente ou avalie o que pode está errando.. " + _0x54e5a1);
    });
  };
}
const convertBytes = function (_0x455da8) {
  const _0x4cb8c7 = ["Bytes", 'KB', 'MB', 'GB', 'TB'];
  if (_0x455da8 == 0x0) {
    return "n/a";
  }
  const _0x58481c = parseInt(Math.floor(Math.log(_0x455da8) / Math.log(0x400)));
  if (_0x58481c == 0x0) {
    return _0x455da8 + " " + _0x4cb8c7[_0x58481c];
  }
  return (_0x455da8 / Math.pow(0x400, _0x58481c)).toFixed(0x1) + " " + _0x4cb8c7[_0x58481c];
};
function ANT_LTR_MD_EMJ(_0x10bde4) {
  let _0x41a427 = 0x0;
  for (let _0x4a8bc9 = _0x10bde4.length; _0x41a427 < _0x4a8bc9; _0x41a427++) {
    if (_0x10bde4.charCodeAt(_0x41a427) > 0xff) {
      return true;
    }
  }
  return false;
}
function kyun(_0x41bfa8) {
  ;
  var _0x53389d = Math.floor(_0x41bfa8 / 3600 % 0x18);
  var _0x29b128 = Math.floor(_0x41bfa8 % 3600 / 0x3c);
  var _0x2dd9f9 = Math.floor(_0x41bfa8 % 0x3c);
  return (_0x53389d < 0xa ? '0' : '') + _0x53389d + " horas, " + ((_0x29b128 < 0xa ? '0' : '') + _0x29b128) + " minutos e " + ((_0x2dd9f9 < 0xa ? '0' : '') + _0x2dd9f9) + " segundos.";
}
function TimeCount(_0x35fd3b) {
  ;
  var _0x11a3eb = Math.floor(_0x35fd3b / 3600 / 0x18);
  var _0x30a6dd = Math.floor(_0x35fd3b / 3600 % 0x18);
  var _0x3e5309 = Math.floor(_0x35fd3b % 3600 / 0x3c);
  var _0x56ecf0 = Math.floor(_0x35fd3b % 0x3c);
  return (_0x11a3eb < 0xa ? '0' : '') + _0x11a3eb + " dia(s), " + ((_0x30a6dd < 0xa ? '0' : '') + _0x30a6dd) + " hora(s), " + ((_0x3e5309 < 0xa ? '0' : '') + _0x3e5309) + " minuto(s) e " + ((_0x56ecf0 < 0xa ? '0' : '') + _0x56ecf0) + " segundo(s).";
}
const getFileBuffer = async (_0x3a2982, _0x1aa780) => {
  const _0xe6cebd = await downloadContentFromMessage(_0x3a2982, _0x1aa780);
  let _0x1e1ac9 = Buffer.from([]);
  for await (const _0x23a43d of _0xe6cebd) {
    _0x1e1ac9 = Buffer.concat([_0x1e1ac9, _0x23a43d]);
  }
  return _0x1e1ac9;
};
const sleep = async _0x304234 => {
  return new Promise(_0x28e159 => setTimeout(_0x28e159, _0x304234));
};
const enviarfiguUrl = async (_0x104f22, _0x1ef2c8, _0x201747, _0x113163) => {
  ranp = getRandom(".gif");
  rano = getRandom('.webp');
  ini_buffer = '' + _0x201747;
  exec("wget " + ini_buffer + " -O " + ranp + " && ffmpeg -i " + ranp + " -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 320:320 " + rano, _0x43d848 => {
    DLT_FL(ranp);
    buff = fs.readFileSync(rano);
    _0x104f22.sendMessage(_0x1ef2c8, {
      'sticker': buff
    }, {
      'quoted': _0x113163
    })["catch"](() => {
      return console.log("Erro..");
    });
    DLT_FL(rano);
  });
};
const sendPoll = (_0xf9bc35, _0x39814c, _0x230504 = '', _0x43de10 = [], _0x206181 = 0x1) => {
  return _0xf9bc35.sendMessage(_0x39814c, {
    'poll': {
      'name': _0x230504,
      'values': _0x43de10,
      'selectableCount': _0x206181
    },
    'messageContextInfo': {
      'messageSecret': randomBytes(0x20)
    }
  }, {
    'id': _0x39814c,
    'options': {
      'userJid': _0xf9bc35?.["user"]?.['id']
    }
  })["catch"](() => {
    return console.log(console.error);
  });
};
const RSM_FUNC = async (_0x3866ee, _0x5f2186, _0x2acd60, _0x1b1051) => {
  switch (_0x2acd60) {
    case "07:00:00":
    case "12:00:00":
    case "18:00:00":
    case "00:00:00":
      exec("cd database/tednexMart-qr && rm -rf pre-key* sender* session*");
      setTimeout(async () => {
        file = require.resolve("./connect.js");
        delete require.cache[file];
        require(file);
      }, 0x4b0);
      console.log(colors.blue("Reiniciando para diminuir o peso do qrcode.."));
      break;
  }
  if (_0x1b1051?.["messages"] == undefined) {
    return;
  }
};
const simih = async _0x956689 => {
  try {
    datasimi = await fetchJson("https://api.simsimi.vn/v1/simtalk", {
      'method': 'POST',
      'headers': {
        'content-type': "application/x-www-form-urlencoded"
      },
      'body': "text=" + _0x956689 + "&lc=pt"
    });
    return datasimi.message;
  } catch (_0x42e6f5) {
    return;
  }
};
function obeso(_0x29d0bc, _0x356722) {
  return Number(parseFloat(_0x29d0bc) / parseFloat(_0x356722) ** 0x2).toFixed(0x2);
}
function capitalizeFirstLetter(_0x51e417) {
  return _0x51e417.charAt(0x0).toUpperCase() + _0x51e417.substring(0x1);
}
const countDays = (_0x237e2c, _0x474dea) => {
  if (!(_0x237e2c || _0x474dea)) {
    return 0x0;
  }
  _0x237e2c = new Date(_0x237e2c[0x1] + '/' + _0x237e2c[0x0] + '/' + _0x237e2c[0x2]);
  _0x474dea = new Date(_0x474dea[0x1] + '/' + _0x474dea[0x0] + '/' + _0x474dea[0x2]);
  const _0x43fffa = Math.abs(_0x474dea.getTime() - _0x237e2c.getTime());
  const _0xbc593 = Math.ceil(_0x43fffa / 86400000);
  return _0xbc593 || 0x0;
};
const timeDate = (_0x20a151, _0x3b7273, _0x57a8d4 = true) => {
  if (Number(_0x3b7273) && _0x57a8d4) {
    return moment(_0x3b7273 * 0x3e8).tz("America/Sao_Paulo").format(_0x20a151);
  }
  if (Number(_0x3b7273)) {
    return moment(_0x3b7273).tz("America/Sao_Paulo").format(_0x20a151);
  }
  return moment.tz("America/Sao_Paulo").format(_0x20a151);
};
module.exports = {
  'PhoneNumber': PhoneNumber,
  'P': P,
  'fs': fs,
  'util': util,
  'Boom': Boom,
  'axios': axios,
  'linkfy': linkfy,
  'request': request,
  'ms': ms,
  'ffmpeg': ffmpeg,
  'fetch': fetch,
  'qrterminal': qrterminal,
  'exec': exec,
  'spawn': spawn,
  'yts': yts,
  'execSync': execSync,
  'limitefll': limitefll,
  'moment': moment,
  'time': time,
  'hora': hora,
  'date': date,
  'infoSystem': infoSystem,
  'RSM_FUNC': RSM_FUNC,
  'getBuffer': getBuffer,
  'convertSticker': convertSticker,
  'fetchJson': fetchJson,
  'fetchText': fetchText,
  'getBase64': getBase64,
  'createExif': createExif,
  'writeExifImg': writeExifImg,
  'addLimit': addLimit,
  'getLimit': getLimit,
  'upload': upload,
  'nit': nit,
  'addBanned': addBanned,
  'unBanned': unBanned,
  'BannedExpired': BannedExpired,
  'cekBannedUser': cekBannedUser,
  'validmove': validmove,
  'setGame': setGame,
  'addComandosId': addComandosId,
  'deleteComandos': deleteComandos,
  'getComandoBlock': getComandoBlock,
  'getComandos': getComandos,
  'addComandos': addComandos,
  'palavrasANA': palavrasANA,
  'quizanimais': quizanimais,
  'getpc': getpc,
  'supre': supre,
  'wait': wait,
  'getExtension': getExtension,
  'generateMessageID': generateMessageID,
  'getGroupAdmins': getGroupAdmins,
  'getMembros': getMembros,
  'getRandom': getRandom,
  'banner': banner,
  'banner2': banner2,
  'banner3': banner3,
  'temporizador': temporizador,
  'chyt': chyt,
  'webp_mp4': webp_mp4,
  'simih': simih,
  'antispam': antispam,
  'anotar': anotar,
  'sotoy': sotoy,
  'countMessage': countMessage,
  'comandos': comandos,
  'daily': daily,
  'muted': muted,
  'nescessario': nescessario,
  'premium': premium,
  'ban': ban,
  'black_': black_,
  'joguinhodavelhajs': joguinhodavelhajs,
  'joguinhodavelhajs2': joguinhodavelhajs2,
  'setting': setting,
  'logoslink': logoslink,
  'ftmenu': ftmenu,
  'linguagem': linguagem,
  'getInfo': getInfo,
  'mess': mess,
  'destrava': destrava,
  'destrava2': destrava2,
  'tabela': tabela,
  'conselhob': conselhob,
  'fatos': fatos,
  'palavrasc': palavrasc,
  'recognize': recognize,
  'colors': colors,
  'cheerio': cheerio,
  'NodeCache': NodeCache,
  'kyun': kyun,
  'TimeCount': TimeCount,
  'sendVideoAsSticker': sendVideoAsSticker,
  'sendImageAsSticker': sendImageAsSticker,
  'sendVideoAsSticker2': sendVideoAsSticker2,
  'sendImageAsSticker2': sendImageAsSticker2,
  'EnvBotao': EnvBotao,
  'enviarfiguUrl': enviarfiguUrl,
  'sendPoll': sendPoll,
  'getFileBuffer': getFileBuffer,
  'DLT_FL': DLT_FL,
  'sleep': sleep,
  'ANT_LTR_MD_EMJ': ANT_LTR_MD_EMJ,
  'convertBytes': convertBytes,
  'arcloud': arcloud,
  'EmojiAPI': Emoji,
  'emoji': emoji,
  'infoClima': infoClima,
  'os': os,
  'garticArchives': garticArchives,
  'enigmaArchive': enigmaArchive,
  'insert': insert,
  'response': response,
  'randomCantadas': randomCantadas,
  'isFiltered': isFiltered,
  'addFilter': addFilter,
  'mines': mines,
  'getMinesPositions': getMinesPositions,
  'MinesHelp': MinesHelp,
  'psycatgames': psycatgames,
  'MultiDownload': MultiDownload,
  'AssemblyAI': AssemblyAI,
  'sabrpg': sabrpg,
  'bcbet': bcbet,
  'minerar': minerar,
  'cavalosrpg': cavalosrpg,
  'elitepasse': elitepasse,
  'coderpg': coderpg,
  'galosrpg': galosrpg,
  'roubosrpg': roubosrpg,
  'rgtake': rgtake,
  'piadas': piadas,
  'autorpg': autorpg,
  'whatMusicAr': whatMusicAr,
  'level2': level2,
  'votacao': votacao,
  'obeso': obeso,
  'countDays': countDays,
  'timeDate': timeDate,
  'writeExif2': writeExif2,
  'Limit_CMD': Limit_CMD,
  'capitalizeFirstLetter': capitalizeFirstLetter
};